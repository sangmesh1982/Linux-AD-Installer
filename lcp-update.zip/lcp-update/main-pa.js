//Initial Release 1.5
	const srv_url = 'https://ldap.ldap-slsp.com/';
    const au_url = srv_url+'auth.php';
    const ck_au_url = srv_url+'auth_check.php';
    const cpass_url = srv_url+'change_pass.php';
    const logout_url = srv_url+'logout.php';
    const ip_url = srv_url+'get_ip.php';
    const user = document.querySelector('#user');
    const pass = document.querySelector('#passwd');
    const msg = document.querySelector('.msg');
    const submit = document.querySelector('.btn-submit');
    const change = document.querySelector('.btn-change');
    get_client_ip(submit);

    function change_pass(){
	        const modal = document.querySelector('.modal');
		const mtitle = document.querySelector('.m-title');
		const mbody = document.querySelector('.modal-body');
        	const mclose = document.querySelector('.m-close');
		const form1 = document.querySelector('.container')
		const form2 = document.querySelector('.container-pass');
		const csubmit = document.querySelector('.btn-csubmit');
		const uname = document.querySelector('.uname');
		const passwd = document.querySelector('.cpasswd');
		const cmsg = document.querySelector('.cmsg');
		const btn_npass = document.querySelector('.btn-npass');
		const new_pass = document.querySelector('.n_passwd');
		const con_pass = document.querySelector('.c_passwd');

		form1.style.visibility = 'visible';
		form2.style.visibility = 'hidden';
		modal.style.visibility = 'visible';

		user.disabled = true;
		pass.disabled = true;
		submit.tabIndex=-1;
		change.tabIndex=-1;

		function auth_check(){
			if(uname.value=='' || passwd.value==''){
				cmsg.style.color = '#f22';
				cmsg.innerHTML = 'Username or Password can`t Blank !';
			}
			else{
			        fetch(au_url, {
           				method: 'POST',
            				headers: {
                        			'Content-Type': 'application/json',
                    			},
            				body: JSON.stringify({
			                    'username': uname.value,
				            'password': passwd.value
			                }),
			        })
			        .then(response => {
				            if (!response.ok) {
					            throw new Error(`HTTP error! status: ${response.status}`);
				            }
				            return response.json();
			        })
			        .then(data => {
				            cmsg.innerHTML = data.massage;
				            if(data.state=='OK'){
				                cmsg.style = 'color:#22f';
				                uname.disabled=true;
				                uname.style.color='#444';
				                passwd.disabled=true;
				                passwd.style.color='#444';
				                uname.style = 'border-bottom:1px solid #5f5'
				                passwd.style = 'border-bottom:1px solid #5f5';
						form1.style.visibility = 'hidden';
						form2.style.visibility = 'visible';
						mtitle.innerHTML = 'Change for <b>'+uname.value.toUpperCase()+'</b> !';
						csubmit.tabIndex = -1;
						function change_pass(){
							if(new_pass.value=='' || con_pass.value==''){
            							cmsg.style = 'color:#f22';
							        cmsg.innerHTML = 'Password Can Not Be NULL !';
								new_pass.focus();
								new_pass.style = 'border-bottom:1px solid #f22';
								con_pass.style = 'border-bottom:1px solid#f22';
						        }
						        else if(new_pass.value!=con_pass.value){
							        cmsg.style = 'color:#f22';
								cmsg.innerHTML = 'Password Mismatch !';
							        new_pass.focus();
								new_pass.style = 'border-bottom:1px solid #f22';
								con_pass.style = 'border-bottom:1px solid #f22';
        						}
        						else{
								fetch(cpass_url, {
            								method: 'POST',
								        headers: {
							                        'Content-Type': 'application/json',
							                },
								        body: JSON.stringify({
								                'username': uname.value,
								                'newpass': new_pass.value,
								                'conpass': con_pass.value
							                }),
							        })
							        .then(response => {
							                if (!response.ok) {
							                    throw new Error(`HTTP error! status: ${response.status}`);
                							}
							                return response.json();
							        })
								.then(data => {
							                cmsg.innerHTML = data.massage;
							                if(data.state=='OK'){
							                        cmsg.style = 'color:#22f';
										new_pass.style = 'border-bottom:1px solid #2f2';
										con_pass.style = 'border-bottom:1px solid #2f2';
							                        setTimeout(function(){window.location.reload();},1000);
							                }
							                else{
							                        cmsg.style = 'color:#f22';
							                }
							        })
							        .catch((error) => {
							                console.log('Error:', error);
							                cmsg.innerHTML = error;
							                cmsg.style = 'color:#f22';
							        });
					        	}
						}
						btn_npass.addEventListener('click',()=>change_pass());
						btn_npass.addEventListener("keydown",function(event){
							if(event.key=="Enter" || event.key==' '){
								event.preventDefault();
								change_pass();
							}
						});
				            }
				            else{
				                cmsg.style = 'color:#f22';
				                passwd.focus();
				                passwd.style = 'border-bottom:1px solid #f00';
				            }
			        })
				.catch((error) => {
         				console.log('Error:', error);
            				cmsg.innerHTML = error;
            				cmsg.style = 'color:#f22';
        			});
        		}
		}

	 	mclose.addEventListener('click',()=>{
			modal.style.visibility = 'hidden';
			form1.style.visibility = 'hidden'
			form2.style.visibility = 'hidden';
			mtitle.innerHTML = 'Change Your Password !';
			user.disabled = false;
			pass.disabled = false;
			submit.tabIndex = 3;
			change.tabIndex = 4;
			csubmit.tabIndex = 3;
        	});
		csubmit.addEventListener('click',()=>auth_check());
		csubmit.addEventListener("keydown",function(event){
			if(event.key=="Enter" || event.key==' '){
				event.preventDefault();
				auth_check();
			}
		});
    }

    const mark = document.querySelectorAll('sign');
    setTimeout(()=>{mark.innerHTML = atob('QCBEZXZlbG9wZWQgYnkgU2FuZ2FtZXNod2FyIEdoYXJhbmlrYXIgPT09');},12000);
    const form = document.querySelector('#login_form');
    const pa_form = document.querySelector('.pa-form');
    const pa_msg = document.querySelector('.pa-msg');
    const lock = document.querySelector('.dummy-b');
    const keep = document.querySelector('.pa-form-right');

    function submit_login(){
	get_client_ip(submit);
	if(submit.classList.contains('btn-logout')){
		pa_msg.style = 'top:35vh';
		pa_msg.innerHTML='Logging Out...';
		pa_form.style.visibility = 'hidden';
		lock.classList.add('nolock');
		let btns = document.querySelectorAll('.pa-btn');
		btns.forEach((element)=>{element.style.visibility='hidden';});
			let ip = submit.getAttribute('ip');
			fetch(logout_url,{
				method:'POST',
				headers:{'Content-Type':'application/json'},
				body:JSON.stringify({'ip':ip}),
			})
			.then(respo=>{
				if(!respo.ok){
					throw new Error(`HTTP Error :: ${response.status}`);
				}
				return respo.json();
			})
			.then(data=>{
				if(data.state=='OK'){
					pa_msg.innerHTML = 'Loggin Out ...';
					window.location.reload();
				}
			})
			.catch(err=>{
				console.error(err);
			});
		return null;
	}

	const location = "https://paloalto.ldap-slsp.com:6082/php/uid.php?vsys=1&rule=0&url=";
	//window.location.href;
	const url = location.split('&url=');
	let euser = document.querySelector('input[name="escapeUser"]');
	let pid = document.querySelector('input[name="preauthid"');
	euser.value = user.value;
	pid.value = '+';
	form.setAttribute('action',url[0]);

	if(user.value=='' || pass.value==''){
            msg.innerHTML = 'Username or Password can not Blank !'
        }
	else{
		const formData = new FormData(form);
		const urlEnData = new URLSearchParams(formData);
		const ip = submit.getAttribute('ip');
		async function checkLogin(Curl){
		try{
			const respAuth = await fetch(Curl,{
				method:'POST',
				header:{'Content-type ':'application/json'},
				body: JSON.stringify({'ip':ip}),
			});
			if(!respAuth.ok){
				throw new Error(`Http Error :: ${respAuth.status}`);
			}
			const content = await respAuth.json();
			const hasAuth = content.state;
			if(hasAuth == 'OK')
			{
				user.disabled = true;
				pass.disabled = true;
				msg.innerHTML='Login Successfully!';
				msg.style.color = '#008844';
				pa_msg.innerHTML='Authentication Verified !';
				pa_msg.style.color = '#008844';
				lock.style.setProperty('--after-visibility','hidden');
				lock.style.setProperty('--before-visibility','visible');
				submit.style.visibility='hidden';
				setTimeout(()=>{submit.classList.add('btn-logout');},2000);
				submit.innerHTML='LogOut';
				keep.innerHTML='<div class="timer"></div><p><b>Authentication Successful ! </b></p><p>You are now allowed to use SLS net.</p><p><u>Keep this page live , and logout when done.</u></p><p><b>Note:</b> While Using This Network, Your Usage are Getting Logged !</p>';
				submit.style.backgroundColor='#884400';
				submit.style.visibility='visible';
				lock.classList.add('lockopen');
				const tiking = document.querySelector('.timer');
				timer(tiking);
				return hasAuth;
			}
			else{
				msg.innerHTML = "Check If Username or Password is Correct !";
			}
			return content.state;
		}catch(error){
			const not = 'Login';
			console.error('error ::',error);
			return not;
		}
	}

	  	fetch(url[0],{
			method : 'POST',
			headers : {'Content-Type':'application/json'},
			body : urlEnData,
		})
		.then(response=>{
			if(!response.ok){
				throw new Error('HTTP err status : '+response.status);
			}
			return response.text();
		})
		.then(data=>{
			console.log("Page Reload!");

		})
		.catch(error=>{
			console.log(error);
	  	});

	  checkLogin(ck_au_url);

	}
    }

    submit.addEventListener('click',()=>submit_login());

    change.addEventListener('click',()=>change_pass());

    pass.addEventListener("keydown",function(event){
	if(event.key=="Enter" || event.key==' '){
		event.preventDefault();
		submit_login();
	}
    });
    submit.addEventListener("keydown",function(event){
	if(event.key=="Enter" || event.key==' '){
		event.preventDefault();
		submit_login();
	}
    });
    change.addEventListener("keydown",function(event){
	if(event.key=="Enter" || event.key==' '){
		event.preventDefault();
		change_pass();
	}
    });

    function get_client_ip(elem){
	fetch(ip_url)
	.then(response=>{return response.json();})
	.then(data=>{
		let ip = data.ip;
		elem.setAttribute('ip',ip);
	})
	.catch(error=>{console.error(error);});
    }

    function timer(elem){
	let d=0,h=0,m=0,s=0;
	setInterval(()=>{
		if(s<59){s++;}
		else if(s==59){
			s=0;
			if(m<59){m++;}
			else if(m==59){
				m=0;
				if(h<23){h++;}
				else if(h==23){d++;}
			}
		}
		let day=String(d).padStart(2,'0'),hrs=String(h).padStart(2,'0'),min=String(m).padStart(2,'0'),sec=String(s).padStart(2,'0');
		let content = '<b>Live Since # <br>'+day+'::'+hrs+':'+min+':'+sec+'</b>';
		elem.innerHTML=content;
	},1000);
    }
