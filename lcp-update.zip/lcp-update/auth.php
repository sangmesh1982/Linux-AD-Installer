<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 03/Sep/2025
Author : Sangameshwar Gharanikar

This PHP is for the verification of credentials 
with LDAP and to log initial status report to the logs director.

Initial Version 1.5
`````````````````````````````````````````````````````````````````````````````````
*/

date_default_timezone_set("Asia/Kolkata");

require_once('environ.php');

$ldap_server = $env['LDAP'];
$ldap_port = $env['LDAP_PORT'];
$ldap_dn = $env['LDAP_DN'];
$serial = $env['SR'];
$sys = ['SM'];

$json_data = file_get_contents('php://input');
$data = json_decode($json_data,true);

$username = $data['username'];
$password = $data['password'];

$ip = $_SERVER['REMOTE_ADDR'];
$comm = [];
exec('nmblookup -A '.$ip, $comm);
$client_str = preg_replace("/\s+/",' ',$comm);

foreach($client_str as $trace){
    if(strpos($trace,'MAC')!==false){
        $client_info=explode('=',$trace);
    }
}

$ldap_conn = ldap_connect($ldap_server, $ldap_port);

if ($ldap_conn) {

    ldap_set_option($ldap_conn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($ldap_conn, LDAP_OPT_REFERRALS, 0);

    $user_dn = $username."@".$ldap_dn;
    $ldap_bind = @ldap_bind($ldap_conn, $user_dn, $password);

    if ($ldap_bind) {
        $msg = ["massage"=>"Authentication successful for user : <b>" . htmlspecialchars($username)."</b>","state"=>"OK"];
    } else {
        $msg = ["massage"=>"Authentication failed. Invalid username or password.","state"=>"NOT"];
    }
    ldap_close($ldap_conn);
} else {
    $msg =  ["massage"=>"Could not connect to LDAP server.","state"=>"NOT"];
}
echo json_encode($msg);
$client = json_encode($_SERVER);
exec ('touch logs/'.escapeshellcmd(htmlspecialchars($username)).'.log');

$content0 = "=================".date('d-M-Y H:i:s')."==================";
$content1 = '=======================================================';
$content2 = '-------------------------------------------------------';
exec ("echo ".$content0." >> logs/".escapeshellcmd(htmlspecialchars($username)).".log");
exec ("echo Client IP : ".$ip." >> logs/".escapeshellcmd(htmlspecialchars($username)).".log");
exec ("echo Client MAC : ".$client_info[1]." >> logs/".escapeshellcmd(htmlspecialchars($username)).".log");
exec ("echo Connection Details : ".$client." >> logs/".escapeshellcmd(htmlspecialchars($username)).".log");
exec ("echo ".$content2." >> logs/".escapeshellcmd(htmlspecialchars($username)).".log");
exec ("echo Status : ".json_encode($msg)." >> logs/".escapeshellcmd(htmlspecialchars($username)).".log");
exec ("echo ".$content2." >> logs/".escapeshellcmd(htmlspecialchars($username)).".log");
exec ("echo ".$content1." >> logs/".escapeshellcmd(htmlspecialchars($username)).".log");

return $msg;

?>
