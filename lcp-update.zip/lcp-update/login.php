<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 03/Sep/2025
Author : Sangameshwar Gharanikar

This PHP is for mapping the LDAP user with current IP adresss and create session

Initial Release 1.5 / Update:1.5.2
`````````````````````````````````````````````````````````````````````````````````
*/
require_once('environ.php');

$json = file_get_contents("php://input");
$data = json_decode($json,true);

$serial = $env['SR'];
$sys = ['SM'];

$user = $env['LDAP_SL'].$data['user'];
$ip = $data['ip'];

$comm = [];
exec('nmblookup -A '.$ip,$comm);
$comm_arr = preg_replace('/\s+/',' ',$comm);

foreach($comm_arr as $trace){
	if(strpos($trace,'MAC')!==false){
			$rcom_info = explode('=',$trace);
			$mac = str_replace('-',':',trim($rcom_info[1]));
		}
}

$url = $env['API_URL'].'?type=user-id&key='.$env['API_KEY'];
$cont = $env['CMD_L_O'].'<entry name="'.$user.'" ip="'.$ip.'" mac="'.$mac.'" timeout="0"></entry>'.$env['CMD_L_C'];

$prefix = $user.'-tmp.xml';
$tmp_path = 'tmp/';

if($tmp_path){
	$tmp_wr = fopen($tmp_path.$prefix,'w+');
	if($tmp_wr){
		fwrite($tmp_wr,$cont);
		fclose($tmp_wr);
		$l_dtls = file_get_contents($tmp_path.$prefix);
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS,'cmd='.urlencode($l_dtls));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($curl, CURLOPT_URL,$url);
		$resp = curl_exec($curl);
		$rerr = curl_error($curl);
		if(strpos($resp,'status="success"')!==false){
			$msg = ['message'=>'Logged in Successfully !','state'=>'OK'];
		}
		else{
			$msg = ['message'=>'Error While Login !','state'=>'NOT'];
		}
		unlink($tmp_path.$prefix);
		curl_close($curl);
	}
}
else{
	$msg = ['message'=>'Check if tmp folder is there!','state'=>'NOT'];
}
echo json_encode($msg);
curl_close($curl);

?>
