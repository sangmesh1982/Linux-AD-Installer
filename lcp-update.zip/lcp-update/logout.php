<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 03/Sep/2025
Author : Sangameshwar Gharanikar

This PHP is for unmapping the LDAP user from current IP adresss 
and clear session

`````````````````````````````````````````````````````````````````````````````````
*/

require_once('environ.php');

$json = file_get_contents("php://input");
$data = json_decode($json,true);
$ip = $data['ip'];
$serial = $env['SR'];
$sys = ['SM'];

$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,false);

$url = "https://".$env['PA']."/api/?type=op&key=".$env['API_KEY']."&cmd=".$env['CMD_1_O'].$ip.$env['CMD_1_C'];
curl_setopt($curl, CURLOPT_URL, $url);
$resp = curl_exec($curl);
$err = curl_error($curl);
if(!$err){
	$url = "https://".$env['PA']."/api/?type=op&key=".$env['API_KEY']."&cmd=".$env['CMD_2_O'].$ip.$env['CMD_2_C'];
	curl_setopt($curl, CURLOPT_URL, $url);
	$resp = curl_exec($curl);
	$err = curl_error($curl);
	if(!$err){
		$url = "https://".$env['PA']."/api/?type=op&key=".$env['API_KEY']."&cmd=".$env['CMD_3_O'].$ip.$env['CMD_3_C'];
		curl_setopt($curl, CURLOPT_URL, $url);
		$resp = curl_exec($curl);
		$err=curl_error($curl);
		if($err){echo $err;}
		}
	else{echo $err;}
}
else{echo $err;}
if(!$err){
$msg=['massage'=>'Logged Out Successfully !','state'=>'OK'];
}
else{
$msg=['massage'=>'Error While Logged Out !','state'=>'NOT'];
}
echo json_encode($msg).PHP_EOL;
curl_close($curl);

?>
