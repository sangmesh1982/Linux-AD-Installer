<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 03/Sep/2025
Author : Sangameshwar Gharanikar

This PHP is for the change of password for the user in LDAP

Initial Version 1.5
`````````````````````````````````````````````````````````````````````````````````
*/

date_default_timezone_set("Asia/Kolkata");

$json_data = file_get_contents('php://input');
$data = json_decode($json_data,true);
$username = $data['username'];
$newPass = $data['newpass'];
$conPass = $data['conpass'];
$serial = $env['SR'];
$sys = ['SM'];

$command = 'sudo -S samba-tool user setpassword '.$username.' --newpassword='.$newPass;

$descr = array(
	0 => array('pipe','r'),
	1 => array('pipe','w'),
	2 => array('pipe','w'));
$pipes = [];
$process = proc_open($command,$descr,$pipes);
if(is_resource($process)){

	fwrite($pipes[0],$passw);
	fclose($pipes[0]);

	$stdout = stream_get_contents($pipes[1]);
	fclose($pipes[1]);

	$stderr = stream_get_contents($pipes[2]);
	fclose($pipes[2]);

	proc_close($process);

	if(strpos($stdout,'OK')!==false){
		$msg = ['massage'=>'Password has been Changed !','state'=>'OK','ERR'=>''];
	}
	else{
		$msg = ['massage'=>'Password Should be of min 8 charactors !','state'=>'NOT','ERR'=>$stderr];
	}
}
else{
	$msg = ['massage'=>'Error While Changing Password !','state'=>'NOT'];
}

echo json_encode($msg);
?>
