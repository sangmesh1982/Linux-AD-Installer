<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 20/April/2026
Author : Sangameshwar Gharanikar

This PHP is for the confirmation of login and status of the users
with LDAP credentials and to log initial report to the FL_logs director.

Initial Release 2.0
`````````````````````````````````````````````````````````````````````````````````
*/

require_once('environ.php');

$serial = $env['SR'];
$sys = ['SM'];

$json = file_get_contents("php://input");
$data = json_decode($json,true);
$ip = $data['ip'];

$client = json_encode($_SERVER);
$ip = $_SERVER['REMOTE_ADDR'];

$cmd_1 = $env['API_URL'].'?type=op&cmd='.$env['CMD_C1_O'].$ip.$env['CMD_C1_C'].'&key='.$env['API_KEY'];
$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);

curl_setopt($curl, CURLOPT_URL,$cmd_1);
$req = curl_exec($curl);
$login_info = $req;
$err = curl_error($curl);
$resp = simplexml_load_string($req);
$resp_j = json_encode($resp);
$status = json_decode($resp_j,true);

$user = $status['result']['entry']['user'];
$state = $status['@attributes']['status'];
if($user!='unknown'){
	$cmd_2 = $env['API_URL'].'?type=op&cmd='.$env['CMD_C2_O'].$user.$env['CMD_C2_C'].'&key='.$env['API_KEY'];
	curl_setopt($curl, CURLOPT_URL,$cmd_2);
	$req = curl_exec($curl);
	$user_info = $req;
	$err = curl_error($curl);

	$resp = simplexml_load_string($req);
	$resp_j = json_encode($resp);
	$status = json_decode($resp_j,true);

	$state = $status['@attributes']['status'];
	if($state=='success'){
		$user_name = explode("\\",$user);
		$msg=['massage'=>'Login Successful !','state'=>'OK', 'User'=>$user_name[1]];
		log_user($user_name,$ip,$msg,$client,$login_info,$user_info);
	}
	else{
		$msg=['massage'=>'Error While Loging !','state'=>'NOT'];
	}
}
else{
	$msg=['massage'=>'Error While Loging !','state'=>'NOT'];
}

echo json_encode($msg);
echo PHP_EOL;

curl_close($curl);

function log_user($user,$ip,$msg,$client,$login_info,$user_info){
	$fo = fopen('FL_logs/'.escapeshellcmd(htmlspecialchars($user[1])).'.log','a+');
	$content = 'SOL>>================================'.date('d-M-Y H:i:s').'====================================='.PHP_EOL;
	$content .='User Name ::'.$user[1].PHP_EOL;
	$content .='IP Address ::'.$ip.PHP_EOL;
	$content .='=============================================================================================='.PHP_EOL;
	$content .='Status ::'.json_encode($msg).PHP_EOL;
	$content .='Connection Details ::'.PHP_EOL.$client.PHP_EOL;
	$content .='=============================================================================================='.PHP_EOL;
	$content .='Firewall Login Details ::'.PHP_EOL;
	$content .= $login_info.PHP_EOL;
	$content .='=============================================================================================='.PHP_EOL;
	$content .='Firewall User Details ::'.PHP_EOL;
	$content .=$user_info.PHP_EOL;
	$content .='=============================================================================================='.PHP_EOL;

	fwrite($fo,$content);
	fclose($fo);

	$flo = fopen('FL_logs/all_clients.log','a+');
	$cont = $user[0].'\\'.$user[1].','.$ip.','.date('d-M-Y H:i:s').PHP_EOL;
	fwrite($flo,$cont);
	fclose($flo);
}

?>
