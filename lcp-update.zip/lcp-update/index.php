<!--/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 03/Sep/2025
Author : Sangameshwar Gharanikar

This is the landing page HTML of Captive Portal

Initial Release 1.5
`````````````````````````````````````````````````````````````````````````````````
*/-->

<!DOCTYPE Html>
<html>
<head>
<title>PaloAlto Authentication Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"">
<meta charset="utf-8">
<link rel="stylesheet" href="https://192.168.122.1/resp/style.css" />
<link rel="icon" type="image/x-icon" href="https://192.168.122.1/resp/favicon.icon" />
</head>
<body>
 <div class="pa-container">
  <div class="pa-head"></div>
  <div class="pa-msg">Authentication Require !</div>
  <div class="pa-form">
   <div class="pa-form-left">
    <div class='dummy-h'></div>
    <div class='dummy-b'></div>
   </div>
   <div class="pa-form-middle">
	<form name='login_form' id='login_form' method='post'>
		<label for='user'>Username :</label>
		<input type='text' name='user' id='user' tabindex='1' />
	    	<label for='passwd'>Password :</label>
	    	<input type='password' name='passwd' id='passwd' tabindex='2' />
	    	<div class='pa-btn btn-submit' type='submit' id='submit' tabindex='3'>Submit</div>
		<div class='pa-btn btn-change' tabindex='4'>Change Password</div>
	 </form>
	<div id="dError" class="msg"></div>
   </div>
   <div class="pa-form-right">
    <p>The Resource You Are Trying To Access Require Proper User Identification.</p>
    <p>Please Enter Credentials.</p>
   </div>
  </div>
 </div>
 <div class='modal'>
  <div class='modal-head'>
	<span class='m-title'>Change Your Password !</span><span class='m-close'>X</span></div>
  <div class='modal-body'>
		<div class="container">
 			<div class="form">
				<label for='uname'>Username : </label>
				<input type='text' name='uname' id='uname' class='uname' tabindex='1' />
				<label for='cpasswd'>Password : </label>
				<input type='password' name='cpasswd' id='cpasswd' class='cpasswd' tabindex='2' />
				<div class="pa-btn btn-csubmit" tabindex='3' >Submit</div>
			</div>
		</div>
		<div class="container-pass">
			<div class='form-pass'>
			  <label for='n_passwd'>New Password : </label>
			  <input type='password' name='n_passwd' id='n_passwd' class='n_passwd' tabindex='1' />
			  <label for='c_passwd'>Confirm : </label>
			  <input type='password' name='c_passwd' id='c_passwd' class='c_passwd' tabindex='2' />
			  <div class="pa-btn btn-npass" tabindex='3' >Submit</div>
			</div>
		</div>
		<div class="cmsg"></div>
	</div>
 </div>
 <sign>@Developed by Sangameshwar Gharanikar ===</sign>
</body>
</html>
<script type="text/javascript" src="https://192.168.122.1/resp/main-ldap.js" ></script>
