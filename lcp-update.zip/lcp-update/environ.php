<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 20/April/2026
Author : Sangameshwar Gharanikar

!Important file to get environmental Veriables.

Initial Release 2.0
`````````````````````````````````````````````````````````````````````````````````
*/
date_default_timezone_set("Asia/Kolkata");
$file='.env';
$op=fopen($file,'r');
$content=fread($op,filesize($file));
$lines = explode(PHP_EOL,$content);
foreach($lines as $line){
	$vars=explode('#',$line);
	if($vars[0]){
		$env[$vars[0]]=$vars[1];
	}
}
//fclose($file);
?>
