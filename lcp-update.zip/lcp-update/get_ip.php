<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 03/Sep/2025
Author : Sangameshwar Gharanikar

!Important file to get the clients IP address.

Initial Release 1.5 / Update:1.5.2
`````````````````````````````````````````````````````````````````````````````````
*/
$cip = $_SERVER["REMOTE_ADDR"];
$ip = ['ip'=>$cip];
echo json_encode($ip);
?>
