<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 20/April/2025
Author : Sangameshwar Gharanikar

!Important file to get the clients IP address.

Initial Release 2.0
`````````````````````````````````````````````````````````````````````````````````
*/

$cip = $_SERVER["REMOTE_ADDR"];
$ip = ['ip'=>$cip];
echo json_encode($ip);
?>
