<?php
/*
`````````````````````````````````````````````````````````````````````````````````
Customised Capative Portal for PaloAlto Firewall to Authenticate LDAP Users

Date : 03/Sep/2025
Author : Sangameshwar Gharanikar

This PHP is for the confirmation of login and status of the users
with LDAP credentials and to log initial report to the FL_logs director.

`````````````````````````````````````````````````````````````````````````````````
*/

date_default_timezone_set('Asia/Kolkata');

require_once('environ.php');
$serial = $env['SR'];
$sys = ['SM'];

$json = file_get_contents("php://input");
$data = json_decode($json,true);
$ip = $data['ip'];

$cmd_1 = $env['API_URL'].'?type=op&cmd='.$env['CMD_C1_O'].$ip.$env['CMD_C1_C'].'&key='.$env['API_KEY'];
$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);

curl_setopt($curl, CURLOPT_URL,$cmd_1);
$req = curl_exec($curl);
$login_info = $req;
$err = curl_error($curl);
$resp = simplexml_load_string($req);
$resp_j = json_encode($resp);
$status = json_decode($resp_j,true);

$user = $status['result']['entry']['user'];
$state = $status['@attributes']['status'];
if($user!='unknown'){
	$cmd_2 = $env['API_URL'].'?type=op&cmd='.$env['CMD_C2_O'].$user.$env['CMD_C2_C'].'&key='.$env['API_KEY'];
	curl_setopt($curl, CURLOPT_URL,$cmd_2);
	$req = curl_exec($curl);
	$user_info = $req;
	$err = curl_error($curl);

	$resp = simplexml_load_string($req);
	$resp_j = json_encode($resp);
	$status = json_decode($resp_j,true);

	$state = $status['@attributes']['status'];
	if($state=='success'){
		$msg=['massage'=>'Login Successful !','state'=>'OK'];
	}
	else{
		$msg=['massage'=>'Error While Loging !','state'=>'NOT'];
	}
}
else{
	$msg=['massage'=>'Error While Loging !','state'=>'NOT'];
}

echo json_encode($msg);
echo PHP_EOL;

curl_close($curl);

$client = json_encode($_SERVER);
$comm = exec('arp ',$ip);
$comm_str = preg_replace('/\s+/',' ',$comm);

$comm_info = explode(' ',$comm_str);
$trace = json_encode($ip);
$trace_arr = json_decode($trace,true);

foreach($trace_arr as $trace){
	if(strpos($trace,$_SERVER['REMOTE_ADDR'])!==false){
		$rcom = preg_replace('/\s+/',' ',$trace);
		$rcom_info = explode(' ',$rcom);
	}
}

$fo = fopen('FL_logs/'.escapeshellcmd(htmlspecialchars($user)).'.log','a+');
$content = 'SOL>>================================'.date('d-M-Y H:i:s').'====================================='.PHP_EOL;
$content .='User Name ::'.$user.PHP_EOL;
$content .='IP Address ::'.$rcom_info[0].PHP_EOL;
$content .='MAC ::'.$rcom_info[2].PHP_EOL;
$content .='=============================================================================================='.PHP_EOL;
$content .='Status ::'.json_encode($msg).PHP_EOL;
$content .='Connection Details ::'.PHP_EOL.$client.PHP_EOL;
$content .='=============================================================================================='.PHP_EOL;
$content .='Firewall Login Details ::'.PHP_EOL;
$content .= $login_info.PHP_EOL;
$content .='=============================================================================================='.PHP_EOL;
$content .='Firewall User Details ::'.PHP_EOL;
$content .=$user_info.PHP_EOL;
$content .='=============================================================================================='.PHP_EOL;
$content .='Connection Trace ::'.PHP_EOL;
foreach($trace_arr as $trace){
$content .= $trace.PHP_EOL;
}
$content .='=========================================================================================<<EOL'.PHP_EOL;
fwrite($fo,$content);
fclose($fo);

?>
