$(document).ready(function(){
	$('sign').html(atob('QCBEZXZlbG9wZWQgYnkgU2FuZ2FtZXNod2FyIEdoYXJhbmlrYXIgPT09'));
	$(".log_out").on("click",function(){
		$.get("get_ip.php",function(data){
			var ip = data;
			$.post("logout.php",{'ip':ip},function(result){
				console.log(result);
				var res = JSON.parse(result);
				if(res.state=="OK")
				{
					$('.msg').html('<h2>'+res.massage+'</h2>');

				}
				else{
					$('.msg').html('<h2>'+res.massage+'</h2>');
				}
			});
		});
	});
});
