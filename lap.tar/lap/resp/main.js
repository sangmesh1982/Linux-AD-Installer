/*<script type='text/JavaScript'>*/
    const btn = document.querySelector('.btn');
    const btn_pass = document.querySelector('.btn-pass');
    const ch_passwd = document.querySelector('.change_pass');
    const msg = document.querySelector('.msg');
    btn.addEventListener('click',function(){
        const uname = document.querySelector('.uname');
        const passwd = document.querySelector('.passwd');
	if(uname.value=='' || passwd.value==''){
		msg.style.color = '#f22';
		msg.innerHTML = 'Username or Password can`t be NULL !';
	}
	else{
        fetch('auth.php', {
            method: 'POST',
            headers: {
                        'Content-Type': 'application/json',
                    },
            body: JSON.stringify({
                    'username': uname.value,
                    'password': passwd.value
                }),
        })
        .then(response => {
            if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {

            msg.innerHTML = data.massage;
            if(data.state=='OK'){
		msg.style = 'color:#22f';
                uname.disabled=true;
                uname.style.color='#444';
                passwd.disabled=true;
                passwd.style.color='#444';
                btn.style.visibility='hidden';
                ch_passwd.style.visibility = 'visible';
		passwd.style = 'border-bottom:1px solid #ccc';
            }
	    else{
		msg.style = 'color:#f22';
	 	passwd.focus();
		passwd.style = 'border-bottom:1px solid #f00';
	    }
        })
        .catch((error) => {
            console.log('Error:', error);
            msg.innerHTML = error;
	    msg.style = 'color:#f22';
        });
	}
    });
    const mark = document.querySelectorAll('sign');
	  mark[0].innerHTML = atob('QCBEZXZlbG9wZWQgYnkgU2FuZ2FtZXNod2FyIEdoYXJhbmlrYXIgPT09');
    ch_passwd.addEventListener('click',function(){
        const modal = document.querySelector('.modal');
        const mclose = document.querySelector('.m-close');
        const mhead = document.querySelector('.m-title');
	const inputs = modal.querySelectorAll('input');
        modal.style.visibility = 'visible';
        modal.style.animation = 'fly-in 0.5s';
        mhead.innerHTML=' For '+uname.value.toUpperCase();
        mclose.addEventListener('click',()=>{
            modal.style.visibility = 'hidden';
            modal.style.animation = '';
	    inputs[0].value='';
	    inputs[1].value='';
        })

    });
    btn_pass.addEventListener('click',function(){
        let new_pass = document.querySelector('.n_passwd');
        let con_pass = document.querySelector('.c_passwd');
        if(new_pass.value=='' || con_pass.value==''){
	    msg.style = 'color:#f22';
            msg.innerHTML = 'Password Can Not Be NULL !';
            new_pass.focus();
        }
        else if(new_pass.value!=con_pass.value){
	    msg.style = 'color:#f22';
            msg.innerHTML = 'Password Mismatch !';
            new_pass.focus();
        }
        else{
            fetch('change_pass.php', {
            method: 'POST',
            headers: {
                        'Content-Type': 'application/json',
                    },
            body: JSON.stringify({
		    'username': uname.value,
                    'newpass': new_pass.value,
                    'conpass': con_pass.value
                }),
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                msg.innerHTML = data.massage;
                if(data.state=='OK'){
			msg.style = 'color:#22f';
                	setTimeout(function(){window.location.reload();},2000);
                }
		else{
			msg.style = 'color:#f22';
		}
            })
            .catch((error) => {
                console.log('Error:', error);
                msg.innerHTML = error;
		msg.style = 'color:#f22';
            });
        }
    });
/*</script>*/
