<!Doctype HTML>
</html>
</head>
<title>LDAP Auth Portal</title>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<link rel='stylesheet' href='resp/style.css'>
</head>
<body>
<div class="container">
    <div class="form">
        <label for='uname'>Username : </label>
        <input type='text' name='uname' id='uname' class='uname' />
        <label for='passwd'>Password : </label>
        <input type='password' name='passwd' id='passwd' class='passwd' />
        <div class="btn">Submit</div>
        <div class="change_pass">Change Password</div>
    </div>
</div>
<div class="msg"></div>
<div class="modal">
    <div class="modal-head"><span class="m-title"></span><span class="m-close">X</span></div>
    <div class="modal-body">
	<div class='form'>
        <label for='n_passwd'>New Password : </label>
        <input type='password' name='n_passwd' id='n_passwd' class='n_passwd' />
        <label for='c_passwd'>Confirm : </label>
        <input type='password' name='c_passwd' id='c_passwd' class='c_passwd' />
        <div class="btn-pass">Submit</div>
	<div class='dummy'></div>
	</div>
    </div>
</div>
<sign>@ Developed by Sangameshwar Gharanikar ===</sign>
</body>
</html>
<script type='text/javascript' src='resp/main.js'></script>
